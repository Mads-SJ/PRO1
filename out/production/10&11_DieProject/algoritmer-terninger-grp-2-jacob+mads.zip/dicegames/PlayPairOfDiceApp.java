package dicegames;

public class PlayPairOfDiceApp {
    public static void main(String[] args) {
        PlayPairOfDice playPairOfDice = new PlayPairOfDice();
        playPairOfDice.startGame();
    }
}
