package dicegames;

public class CrapsPlayApp {
    public static void main(String[] args) {
        CrapsPlay crapsPlay = new CrapsPlay();
        crapsPlay.startGame();
    }
}
