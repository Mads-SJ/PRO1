package dicegames;

public class PigGameApp {
    public static void main(String[] args) {
        PigGame pigGame = new PigGame();
        pigGame.startGame();
    }
}
