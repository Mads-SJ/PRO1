package application.model;

import java.time.LocalDate;

public class Konference {
    private String navn;
    private LocalDate startDato;
    private LocalDate slutDato;
    private String lokation;
    private double dagspris;
    private LocalDate tilmeldingsfrist;

    public Konference(String navn, LocalDate startDato, LocalDate slutDato, String lokation, double dagspris, LocalDate tilmeldingsfrist) {
        this.navn = navn;
        this.startDato = startDato;
        this.slutDato = slutDato;
        this.lokation = lokation;
        this.dagspris = dagspris;
        this.tilmeldingsfrist = tilmeldingsfrist;
    }

    public String getNavn() {
        return navn;
    }

    public LocalDate getStartDato() {
        return startDato;
    }

    public LocalDate getSlutDato() {
        return slutDato;
    }

    public String getLokation() {
        return lokation;
    }

    public double getDagspris() {
        return dagspris;
    }

    public LocalDate getTilmeldingsfrist() {
        return tilmeldingsfrist;
    }
}
