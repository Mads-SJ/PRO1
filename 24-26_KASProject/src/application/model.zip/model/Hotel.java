package application.model;

import java.util.ArrayList;

public class Hotel {
    private String navn;
    private double dagspris;
    private String lokation;

    public Hotel(String navn, double dagspris, String lokation) {
        this.navn = navn;
        this.dagspris = dagspris;
        this.lokation = lokation;
    }

    public String getNavn() {
        return navn;
    }

    public double getDagspris() {
        return dagspris;
    }

    public String getLokation() {
        return lokation;
    }
}
